#pragma once
#include "PlayerFactoryPattern.h"
#include "PlayerBase.h"

class PlayerBlackFactory : public PlayerFactoryPattern {
public:
    unique_ptr<PlayerBase> CreatePlayer();
};