#include "PlayerBlackFactory.h"
#include "PlayerBase.h"
#include "PlayerBlack.h"

unique_ptr<PlayerBase> PlayerBlackFactory::CreatePlayer(){
    return make_unique<PlayerBlack>();
}