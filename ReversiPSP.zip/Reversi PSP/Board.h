#pragma once
#include <iostream>
#include <string>
#include <iomanip>
#include <Windows.h>
#include <map>
#include <cctype>
#include <vector>

using namespace std;

class Board {
public:
    map<pair<char, short>, char> boardInfo;
    map<char, short> columnNumberByLetter;
    char columnLetters[8] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };
    short whitePoints = 0;
    short blackPoints = 0;

    Board();
    void PrintBoard();
    void UpdateBoard(char letter, short number, char player);
    void Reversing(vector<pair<char, short>> flanks, char player);
    bool IsActionInCenter();
    void GameEnding();
    void CalculatePoints();

private:
    void Row();
    void Columns(short row);
};

