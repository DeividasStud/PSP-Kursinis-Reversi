#pragma once
#include "PlayerBase.h"
#include "Board.h"

class PlayerBlack : public PlayerBase {
public:
    PlayerBlack();
    void UpdateDisks(Board& board);
};

