#include "DiskPlacementCommand.h"
#include "CommandPattern.h"
#include "Board.h"

DiskPlacementCommand::DiskPlacementCommand(Board& board, char colLet, int rowNum, char plr)
    : gameBoard(board), columnLetter(colLet), rowNumber(rowNum), player(plr) {}

void DiskPlacementCommand::Execute() {
    gameBoard.UpdateBoard(columnLetter, rowNumber, player);
}
