#pragma once
#include "PlayerBase.h"
#include "Board.h"

class PlayerWhite : public PlayerBase {
public:
    PlayerWhite();
    void UpdateDisks(Board& board);
};
