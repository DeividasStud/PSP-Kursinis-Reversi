#pragma once
#include "PlayerFactoryPattern.h"
#include "PlayerBase.h"

class PlayerWhiteFactory : public PlayerFactoryPattern {
public:
    unique_ptr<PlayerBase> CreatePlayer();
};

