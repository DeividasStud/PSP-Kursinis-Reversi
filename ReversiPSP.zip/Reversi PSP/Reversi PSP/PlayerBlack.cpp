#include "PlayerBlack.h"
#include "DiskPlacementCommand.h"
#include "Board.h"

PlayerBlack::PlayerBlack() {
    columnLetter = ' ';
    rowNumber = 0;
}
void PlayerBlack::UpdateDisks(Board& board) {
    board = this->gameBoard;
    DiskPlacementCommand diskPlacementCommand(board, columnLetter, rowNumber, 'B');
    diskPlacementCommand.Execute();
}