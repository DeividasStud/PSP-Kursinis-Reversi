#pragma once
#include "PlayerBase.h"

class PlayerFactoryPattern {
public:
    virtual unique_ptr<PlayerBase> CreatePlayer() = 0;
    virtual ~PlayerFactoryPattern() {}
};

