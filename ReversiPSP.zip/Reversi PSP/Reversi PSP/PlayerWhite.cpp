#include "PlayerWhite.h"
#include "DiskPlacementCommand.h"
#include "Board.h"

PlayerWhite::PlayerWhite() {
    columnLetter = ' ';
    rowNumber = 0;
}
void PlayerWhite::UpdateDisks(Board& board) {
    board = this->gameBoard;
    DiskPlacementCommand diskPlacementCommand(board, columnLetter, rowNumber, 'W');
    diskPlacementCommand.Execute();
}