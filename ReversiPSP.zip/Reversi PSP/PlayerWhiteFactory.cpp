#include "PlayerWhiteFactory.h"
#include "PlayerBase.h"
#include "PlayerWhite.h"

unique_ptr<PlayerBase> PlayerWhiteFactory::CreatePlayer() {
    return make_unique<PlayerWhite>();
}