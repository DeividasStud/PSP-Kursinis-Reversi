#include "PlayerBase.h"
#include "Board.h"

#define Deletion "\33[2K\r"
#define PreviousLine "\033[A\r"

void RowDeletion(int rowCount);

void PlayerBase::Input(char player) {
    string userInput = "";
    char columnLetter = ' ';
    short rowNumber = 0;
    const short minRowNumber = 1;
    const short maxRowNumber = 8;

    while (true) {
        getline(cin, userInput);
        if (!userInput.empty() && userInput.length() >= 2) {
            columnLetter = userInput[0];
            if (isdigit(userInput[1])) rowNumber = stoi(userInput.substr(1, 1));
            if (!isdigit(columnLetter) && rowNumber > 0) break;
        }
        RowDeletion(1);
    }

    if (rowNumber < minRowNumber || rowNumber > maxRowNumber
        || toupper(columnLetter) > 'H'
        || toupper(columnLetter) < 'A'
        || !IsInputValid(player, toupper(columnLetter), rowNumber)) {
        RowDeletion(1);
        Input(player);
    }
    else {
        RowDeletion(1);
        this->columnLetter = toupper(columnLetter);
        this->rowNumber = rowNumber;
        if (flanks.size() > 0) {
            Reversing(gameBoard, player);
            flanks.clear();
        }
    }
}
void PlayerBase::GetGameBoardInfo(Board& board) {
    this->gameBoard = board;
    this->boardInfo = board.boardInfo;
    this->isActionInCenter = board.IsActionInCenter();
}
bool PlayerBase::IsGameEnding(char opponent) {
    if (isActionInCenter) return false;
    bool canFlank = false;
    for (auto tile : boardInfo) {
        if (tile.second == 'O') {
            for (auto direction : directions) {
                CanFlankOpponent(direction[0], direction[1], opponent, GetColumnNumber(tile.first.first), tile.first.second);
                if (currentFlanks.size() > 0) {
                    canFlank = true;
                }
                currentFlanks.clear();
                if (canFlank) {
                    return false;
                }
            }
        }
    }
    return true;
}
bool PlayerBase::IsInputValid(char player, char colLetter, short rowNum) {
    if (isActionInCenter) {
        if ((colLetter == 'D' && rowNum == 4 && boardInfo[{'D', 4}] == 'O')
            || (colLetter == 'D' && rowNum == 5 && boardInfo[{'D', 5}] == 'O')
            || (colLetter == 'E' && rowNum == 4 && boardInfo[{'E', 4}] == 'O')
            || (colLetter == 'E' && rowNum == 5) && boardInfo[{'E', 5}] == 'O') return true;
    }
    else {
        if (boardInfo[{colLetter, rowNum}] == 'O') {
            char opponent = (player == 'B') ? 'W' : 'B';
            short currentColNum = GetColumnNumber(colLetter);

            for (auto direction : directions) {
                short x = direction[0];
                short y = direction[1];

                if (boardInfo[{GetColumnLetterByNumber(currentColNum + x),
                    rowNum + y}] == opponent) {
                    currentFlanks.clear();
                    if (CanFlankOpponent(x, y, opponent, currentColNum, rowNum)) {
                        if (currentFlanks.size() > 0) {
                            flanks.insert(flanks.end(), currentFlanks.begin(), currentFlanks.end());
                        }
                    }
                }
            }
            if (flanks.size() > 0) return true;
        }
    }
    return false;
}
bool PlayerBase::CanFlankOpponent(short flankingDirX, short flankingDirY, char opponent, short currentX, short currentY) {
    short dirX = currentX + flankingDirX;
    short dirY = currentY + flankingDirY;

    currentFlanks.push_back({ GetColumnLetterByNumber(dirX), dirY });
    if (boardInfo[{GetColumnLetterByNumber(dirX), dirY}] == NULL
        || boardInfo[{GetColumnLetterByNumber(dirX), dirY}] == 'O') {
        currentFlanks.clear();
        return false;
    }
    else if (boardInfo[{GetColumnLetterByNumber(dirX), dirY}] == opponent) {
        CanFlankOpponent(flankingDirX, flankingDirY, opponent, dirX, dirY);
    }
    else {
        currentFlanks.pop_back();
        return true;
    }
}
void PlayerBase::Reversing(Board& board, char player) {
    board.Reversing(flanks, player);
}
short PlayerBase::GetColumnNumber(char letter) {
    return gameBoard.columnNumberByLetter[letter];
}
char PlayerBase::GetColumnLetterByNumber(short indx) {
    return gameBoard.columnLetters[indx - 1];
}

void RowDeletion(int rowCount) {
    for (int i = 0; i < rowCount; i++) {
        cout << PreviousLine;
        cout << Deletion;
    }
}