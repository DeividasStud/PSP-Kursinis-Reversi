#pragma once
#include "Board.h"
#include <map>
#include <vector>
class PlayerBase {
public:
    Board gameBoard;
    map<pair<char, short>, char> boardInfo;
    bool isActionInCenter = true;

    virtual void UpdateDisks(Board& board) = 0;
    void Input(char player);
    void GetGameBoardInfo(Board& board);
    bool IsGameEnding(char opponent);
protected:
    char columnLetter = ' ';
    short rowNumber = 0;
    short directions[8][2] = {
         {-1, 0}, {1, 0}, {0, -1}, {0, 1},
         {-1, -1}, {-1, 1}, {1, -1}, {1, 1} };
    vector<pair<char, short>> flanks;
    vector<pair<char, short>> currentFlanks;

    bool IsInputValid(char player, char colLetter, short rowNum);
    bool CanFlankOpponent(short flankingDirX, short flankingDirY, char opponent, short currentX, short currentY);
    void Reversing(Board& board, char player);
    short GetColumnNumber(char letter);
    char GetColumnLetterByNumber(short indx);
};

