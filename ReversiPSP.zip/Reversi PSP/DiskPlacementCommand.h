#pragma once
#include "CommandPattern.h"
#include "Board.h"
class DiskPlacementCommand : public CommandPattern {
private:
    Board& gameBoard;
    char player;
    char columnLetter;
    int rowNumber;

public:
    DiskPlacementCommand(Board& board, char colLet, int rowNum, char plr);
    void Execute();
};

