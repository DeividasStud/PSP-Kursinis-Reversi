#pragma once
class CommandPattern {
public:
    virtual void Execute() = 0;
};

