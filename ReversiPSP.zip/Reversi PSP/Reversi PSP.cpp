#include <string>
#include <Windows.h>
#include <deque>
#include <cctype>
#include "Board.h"
#include "CommandPattern.h"
#include "DiskPlacementCommand.h"
#include "PlayerBase.h"
#include "PlayerBlack.h"
#include "PlayerWhite.h"
#include "PlayerFactoryPattern.h"
#include "PlayerBlackFactory.h"
#include "PlayerWhiteFactory.h"

using namespace std;

void PlayerRotation(deque<unique_ptr<PlayerBase>>& players, char &whichPlayersTurn, 
    char &opponent, bool& isFinished, Board& board);

int main()
{
    SetConsoleOutputCP(CP_UTF8);
    wcout.imbue(std::locale("en_US.UTF-8"));

    bool isFinished = false;
    char whichPlayersTurn = 'B';
    char opponent = 'W';

    deque<unique_ptr<PlayerBase>> players;
    Board board;

    PlayerBlackFactory playerBlackFactory;
    PlayerWhiteFactory playerWhiteFactory;

    players.push_back(playerBlackFactory.CreatePlayer());
    players.push_back(playerWhiteFactory.CreatePlayer());

    board.PrintBoard();

    while (!isFinished) {
        PlayerRotation(players, whichPlayersTurn, opponent, isFinished, board);
    }
    return 0;
}

void PlayerRotation(deque<unique_ptr<PlayerBase>>& players, char& whichPlayersTurn, 
    char& opponent, bool& isFinished, Board& board) {
    for (auto& player : players) {
        if (dynamic_cast<PlayerBlack*>(player.get())) {
            whichPlayersTurn = 'B';
            opponent = 'W';
        }
        else if (dynamic_cast<PlayerWhite*>(player.get())) {
            whichPlayersTurn = 'W';
            opponent = 'B';
        }
        player->GetGameBoardInfo(board);
        if (player->IsGameEnding(opponent)) {
            board.GameEnding();
            isFinished = true;
            break;
        }
        player->Input(whichPlayersTurn);
        player->UpdateDisks(board);
    }
}
