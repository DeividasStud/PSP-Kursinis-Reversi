#include "Board.h"
#include <iostream>
#include <string>
#include <iomanip>
#include <Windows.h>
#include <map>
#include <cctype>
#include <vector>

Board::Board() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            boardInfo[{columnLetters[i], j + 1}] = 'O';
        }
        columnNumberByLetter[columnLetters[i]] = i + 1;
    }
}
void Board::PrintBoard() {
    cout << setw(63) << "BLACK DISKS PLAYER TURN\n\n";
    cout << setw(65) << " A   B   C   D   E   F   G   H\n";
    for (int i = 0; i < 8; i++) {
        Row();
        cout << setw(32) << i + 1;
        Columns(i);
    }
    Row();
    cout << endl << setw(77) << "Rules: First type letter, then number; (Example: D5)\n\n";
}
void Board::UpdateBoard(char letter, short number, char player) {
    wstring color = L"";

    boardInfo[{letter, number}] = player;

    wcout << L"\x1b[0;39H";
    if (player == 'B') {
        color = L"\033[42;30m�\033[42;30m";
        wcout << L"\033[0mWHITE DISKS PLAYER TURN\033[0m";
    }
    else if (player == 'W') {
        color = L"\033[42;37m�\033[42;30m";
        wcout << L"\033[0mBLACK DISKS PLAYER TURN\033[0m";
    }
    wcout << L"\x1b[" << number * 2 + 3 << ";" << 32 + columnNumberByLetter[letter] * 4 << "H";
    wcout << color;
    wcout << L"\x1b[24;0H\033[0m";
}
void Board::Reversing(vector<pair<char, short>> flanks, char player) {
    for (auto tile : flanks) {
        UpdateBoard(tile.first, tile.second, player);
    }
}
bool Board::IsActionInCenter() {
    if (boardInfo[{'D', 4}] == 'O' || boardInfo[{'D', 5}] == 'O'
        || boardInfo[{'E', 4}] == 'O' || boardInfo[{'E', 5}] == 'O') return true;
    return false;
}
void Board::GameEnding() {
    CalculatePoints();
    cout << "\n\n\nGAME ENDED\n";
    if (whitePoints > blackPoints) cout << "Winner is White disks player!\n";
    else if (whitePoints < blackPoints) cout << "Winner is Black disks player!\n";
    cout << "Black disks player points: " << blackPoints << endl;
    cout << "White disks player points: " << whitePoints << endl;
}
void Board::CalculatePoints() {
    for (auto tile : boardInfo) {
        if (tile.second == 'W') whitePoints++;
        else if (tile.second == 'B') blackPoints++;
    }
}
void Board::Row() {
    cout << setw(79) << "\033[42;30m---------------------------------\033[0m\n";
}
void Board::Columns(short row) {
    cout << setw(10) << "\033[42;30m|";
    for (int i = 0; i < 8; i++) {
        cout << "   |";
    }
    cout << "\033[0m\n";
}