#include "pch.h"
#include "CppUnitTest.h"
#include "../Reversi PSP/Board.h"
#include "../Reversi PSP/Board.cpp"
#include "../Reversi PSP/PlayerBase.h"
#include "../Reversi PSP/PlayerBase.cpp"
#include "../Reversi PSP/PlayerWhite.h"
#include "../Reversi PSP/PlayerWhite.cpp"
#include "../Reversi PSP/DiskPlacementCommand.h"
#include "../Reversi PSP/DiskPlacementCommand.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ReversiTests
{
	TEST_CLASS(ReversiTests)
	{
	public:
		
		TEST_METHOD(BoardDiskUpdateTest)
		{
			Board board;
			board.UpdateBoard('A', 1, 'W');
			Assert::AreEqual('W', board.boardInfo[{'A', 1}]);
		}
		TEST_METHOD(IsActionInCenterTest) {
			Board board;
			Assert::IsTrue(board.IsActionInCenter());
		}
		TEST_METHOD(IsActionOutOfCenterTest) {
			Board board;
			board.boardInfo[{'D', 5}] = 'B';
			board.boardInfo[{'E', 4}] = 'B';
			board.boardInfo[{'D', 4}] = 'W';
			board.boardInfo[{'E', 5}] = 'W';
			Assert::IsFalse(board.IsActionInCenter());
		}
		TEST_METHOD(IsGameEndingTest) {
			Board board;
			PlayerWhite playerWhite;
			playerWhite.isActionInCenter = false;
			char columnLetters[8] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					board.boardInfo[{columnLetters[i], j + 1}] = 'B';
				}
			}
			Assert::IsTrue(playerWhite.IsGameEnding('B'));
		}
		TEST_METHOD(PointCalculationTest) {
			Board board;
			board.boardInfo[{'D', 4}] = 'W';
			board.boardInfo[{'D', 5}] = 'W';
			board.boardInfo[{'E', 4}] = 'B';
			board.boardInfo[{'E', 5}] = 'B';
			board.boardInfo[{'F', 4}] = 'B';
			board.boardInfo[{'G', 5}] = 'B';
			board.CalculatePoints();
			Assert::AreEqual((short)4, board.blackPoints);
		}
	};
}
